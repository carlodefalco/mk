#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include<vector>

#define CLIENT_INFO " <<CLIENT INFO>>" 

#include "../src/nanoshaper.h"
  
int main(int argc, char* argv[])
{    
    NS::surface_type surf_type = NS::skin;
    double skin_param = 0.45;
    double stern_layer = 2.;
    double radius = 2.0;
    double charge = 1;
    double dielectric=0;
    unsigned numberOfThreads = 1;

    std::vector<NS::Atom> atoms;

    //4 spheres almost coplanar on z=0 plane
    atoms.push_back(NS::Atom(5., 10.,0.01, radius,charge,dielectric));
    atoms.push_back(NS::Atom(10.,10.,0.02, radius,charge,dielectric));
    atoms.push_back(NS::Atom(5., 5.,-0.03, radius,charge,dielectric));
    atoms.push_back(NS::Atom(10.,5.,-0.04, radius,charge,dielectric));
    
    NS::NanoShaper ns(atoms,surf_type,skin_param,stern_layer,numberOfThreads);
    
    ns.setConfig<double>("Grid_scale", 3.0 );
    // 50 is needed for small number of atoms
    ns.setConfig<double>("Grid_perfil", 50.0 );
            
    ns.buildAnalyticalSurface();
    
    unsigned ix = 2;
    unsigned iy = 1;
    unsigned iz = 3;
    std::vector<unsigned> gridSize;
    std::vector<double> coords;
        
    bool gridReady = ns.getGridSize(gridSize);    
    std::cout << std::endl << CLIENT_INFO << " Grid is ready " << gridReady;
        
    short val =  ns.getGridPointStatus(ix,iy,iz);      
    std::cout << std::endl << CLIENT_INFO << " Grid val " << val;    
    
    // colour coarse grained grid (status map)
    ns.colourGrid();
    
    gridReady = ns.getGridSize(gridSize);    
    
    std::cout << std::endl << CLIENT_INFO << " Grid is ready2 " << gridReady;    
    
    if (gridReady)
    {
        std::cout << std::endl << CLIENT_INFO << " Grid size " << gridSize[0] << " " << gridSize[1] << " " << gridSize[2]; 
    
        val =  ns.getGridPointStatus(ix,iy,iz); 
        std::cout << std::endl << CLIENT_INFO << " Grid val " << val;    
    
        ns.getGridPointCoordinates(ix,iy,iz,coords);
        std::cout << std::endl << CLIENT_INFO << " Coords " << coords[0] << " " << coords[1] << " " << coords[2]; 
            
        ns.triangulate();
        // few rays 
        system("cp triangulatedSurf.off lowRes.off");                               
    }
    
    // same grid, more rays, more accurate triangulation        
    NS::NanoShaper ns2(atoms,surf_type,skin_param,stern_layer,numberOfThreads);        
    ns2.setConfig<double>("Grid_scale",3.0);
    ns2.setConfig<double>("Grid_perfil",50.0);
    ns2.setConfig<bool>("Accurate_Triangulation",true);                
    ns2.buildAnalyticalSurface();
    ns2.colourGrid();
    ns2.triangulate();
    system("cp triangulatedSurf.off highRes.off");           
    
    // play with grid and rays
    double startp[3]={7.5,2,0};    
    double offset = 11;
    double endp[3]={startp[0],startp[1]+offset,startp[2]};    
    unsigned y_direction = 1;
    bool computeNormals = false;
    std::vector<unsigned> indices;
    ns2.getNearestGridPoint(startp,indices);
    std::cout << std::endl << CLIENT_INFO << " Start point on the grid " << indices[0] << " " << indices[1] << " " << indices[2]; 
    short stat = ns2.getGridPointStatus(indices[0],indices[1],indices[2]);    
    int startx = indices[0];
    int starty = indices[1];
    int startz = indices[2];
    
    std::cout << std::endl << CLIENT_INFO << " Status " << stat;
    ns2.getNearestGridPoint(endp,indices);    
    int endy = indices[1];    
    
    std::cout << std::endl << CLIENT_INFO << " End point on the grid " << indices[0] << " " << indices[1] << " " << indices[2]; 
    stat = ns2.getGridPointStatus(indices[0],indices[1],indices[2]);        
    std::cout << std::endl << CLIENT_INFO << " Status " << stat;
    
    for (int i=starty;i<=endy;i++)
    {
        stat = ns2.getGridPointStatus(startx,i,startz);        
        std::cout << std::endl << CLIENT_INFO << " Status " << stat << " index " << i;
    }
    
    std::vector<std::pair<double,double*> > inters;        
    // this call prepare the datastuctures. Call it if you change direction of ray casting
    // this is done outside as it is an expensive function hence if multiple rays are cast
    // in the same direction it is convenient to call it separately 
    ns2.setDirection(y_direction);
    ns2.castAxisOrientedRay(startp,endp[y_direction],inters,y_direction,computeNormals);    
    std::cout << std::endl << CLIENT_INFO <<"Ray path:" ;
    for (unsigned i=0;i<inters.size();i++)
        std::cout << std::endl << CLIENT_INFO << "Hit at " << inters[i].first;
    
    inters.clear();        
    startp[0]=startp[0]-2.5;
    endp[0]=endp[0]-2.5;
    // same direction, we don't need to call setDirection again
    ns2.castAxisOrientedRay(startp,endp[y_direction],inters,y_direction,computeNormals);    
    
    std::cout << std::endl << CLIENT_INFO << "Ray path:" ;
    for (unsigned i=0;i<inters.size();i++)
        std::cout << std::endl << CLIENT_INFO << "Hit at " << inters[i].first;
        
    std::cout << std::endl; 
    return 0;
}


