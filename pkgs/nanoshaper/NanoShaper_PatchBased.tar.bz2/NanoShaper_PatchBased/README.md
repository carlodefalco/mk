# NanoShaper 

NanoShaper is GPL licensed software please read the attached license.txt file.


1. Contents

	A. Files and folders to compile NanoShaper
	- "\build" build directory for standalone application
	- "\build_lib" build directory for DelPhi library
	- "\CGALPatch" CGAL patch files
	- "\src" C++ sources
	- "setup.py" python setup file
	- "\doc" C++ automatically generated classes documentation

	B. Example input files for standalone NanoShaper
	- "\example" 

	C. Package with precompiled executable and dependencies
	- "pkg_nanoshaper_0.7.8.tar.gz" 

	D. Docker file and image
	- "Dockerfile" 
	-  docker image from GitLab Registry

	

2. Installation

	Two modes are possible:
	
	- A. In the automatic mode you just type
	
	```bash
	python setup.py
	```	
	and a user friendly installation will start.

	- B. The other possibility is the manual compilation and it is valid
	for any O.S. This mode is detailed on the UserGuide pdf.

3. Execution
	
	Three modes are possible:
	- A. Running the NanoShaper executable file if you installed as described above
	  ```console
	  cd <Path of the directory where input files are>
	  NanoShaper  <Surface Configuration file>
	   ```
	   after properly adding the NanoShaper executable path to your $PATH variable
	- B. From the package with precompiled executable and dependencies 
	
	  unpack pkg_nanoshaper_0.7.8.tar.gz 

	  ```console
	  tar xvzf pkg_nanoshaper_0.7.8.tar.gz
	  ```
	  and just type
	  
	  ```console
	  cd <Path of the directory where input files are>
	  NanoShaper <Surface Configuration file>
	   ```
	    after properly adding the NanoShaper executable path to your $PATH variable
	- C. From the docker image on GitLab
		
		```console
	  	docker run -it --mount type=bind,source=<Complete path of the directory where input files are>,target=/App gitlab.iit.it:4567/sdecherchi/nanoshaper:0.7.8 <Surface Configuration file>
	  	```
		Note that you need to install docker on your system. 

		In order to use nanoshaper docker image inside the molecolar visualization software VMD:
		rename NanoShaper_Docker_VMD.sh into NanoShaper and add its path to your $PATH variable.
		In some more recent OS X systems (e.g., Big Sur) you may need to change the VMD default temporary folder using the VMDTMPDIR env variable 	      because of permission issues.
		


